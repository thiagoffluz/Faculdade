#include <gl/gl.h>
#include <gl/glu.h>

#define tamanho 512


void viraEsquerda();
void viraDireita();

void caminhaPraFrente();
void caminhaPraTras();

void viewport_topo();
void viewport_perspectiva();

void draw_perspectiva();
void draw_obj();
void draw_topo();
